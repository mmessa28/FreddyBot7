# Freddy-Bot6Final

WhatsApp Gruppenmoderator-Bot ohne Puppeteer – blockiert Fremdwerbung, Beleidigungen und doppelte Nachrichten.
